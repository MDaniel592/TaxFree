# TaxFree

The extension removes TAXES from amazon sites (EU). Furthermore, you can introduce your desired/current tax of your current country to see the final price you will pay.

**The extension is supported in Firefox only.**
### Copyright

I use some third-party scripts in our add-on. The authors and licenses are listed below.


- [ClearURLs](https://github.com/ClearURLs/Addon) | Copyright 2017-2020 | GNU LGPLv3
- [Bootstrap](https://github.com/twbs/bootstrap) | Copyright 2011-2016 Twitter, Inc. | MIT
- [SendHerePlz](https://github.com/sdelquin/sendhereplz) | Copyright 2017-2020 | GNU GPLv3
- [jQuery](https://github.com/jquery/jquery) | Copyright JS Foundation and other contributors | MIT

### Disclamer

The manifestv3 has not been tested. The extension may not work if you decide to use manifestv3.